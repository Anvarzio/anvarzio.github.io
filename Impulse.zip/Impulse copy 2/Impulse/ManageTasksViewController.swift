import UIKit

class ManageTasksViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var taskNameTextField: UITextField!
    @IBOutlet weak var dueDatePicker: UIDatePicker!
    @IBOutlet weak var tableView: UITableView!

    let taskStore = TaskStore.shared

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        title = "Tasks"
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

    @IBAction func addTaskTapped(_ sender: UIButton) {
        guard let taskName = taskNameTextField.text,
              !taskName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return
        }

        let alert = UIAlertController(
            title: "Completion Time",
            message: "Enter estimated completion time in hours",
            preferredStyle: .alert
        )

        alert.addTextField { textField in
            textField.placeholder = "Example: 2.5"
            textField.keyboardType = .decimalPad
        }

        let addAction = UIAlertAction(title: "Save Task", style: .default) { _ in
            guard let completionText = alert.textFields?.first?.text,
                  let completionHours = Double(completionText),
                  completionHours > 0 else {
                return
            }

            let newTask = Task(
                name: taskName,
                dueDate: self.dueDatePicker.date,
                completionTimeHours: completionHours
            )

            self.taskStore.tasks.append(newTask)
            self.taskNameTextField.text = ""
            self.tableView.reloadData()
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)

        alert.addAction(cancelAction)
        alert.addAction(addAction)

        present(alert, animated: true)
    }
    
    @IBAction func toggleEditingMode(_ sender: UIButton) {
        if tableView.isEditing {
            tableView.setEditing(false, animated: true)
            sender.setTitle("Manage", for: .normal)
        } else {
            tableView.setEditing(true, animated: true)
            sender.setTitle("Done", for: .normal)
        }
        tableView.allowsSelection = !tableView.isEditing
    }

    // MARK: - Table View Data Source

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return taskStore.tasks.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let task = taskStore.tasks[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath)

        var content = cell.defaultContentConfiguration()
        content.text = task.name
        
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        content.secondaryText = formatter.string(from: task.dueDate)
        
        cell.contentConfiguration = content
        
        let score = task.priorityScore()
        cell.backgroundColor = colorForPriority(score)
        
        return cell
    }

    // MARK: - Delete Task

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            taskStore.tasks.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    func tableView(_ tableView: UITableView,
                   canEditRowAt indexPath: IndexPath) -> Bool {
        return tableView.isEditing
    }
    
    func colorForPriority(_ score: Double) -> UIColor {
        // score should be from 0.0 to 1.0
        // higher score = more red
        
        let red = 1.0
        let green = 1.0 - (0.5 * score)
        let blue = 1.0 - (0.5 * score)
        
        return UIColor(
            red: red,
            green: green,
            blue: blue,
            alpha: 1.0
        )
    }
}
