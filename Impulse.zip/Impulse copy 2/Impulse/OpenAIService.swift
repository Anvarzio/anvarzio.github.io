//
//  OpenAIService.swift
//  Impulse
//
//  Created by Tony V on 2/27/26.
//

import Foundation

final class OpenAIService {
    private let apiKey: String
    private let session: URLSession

    init(apiKey: String, session: URLSession = .shared) {
        self.apiKey = apiKey
        self.session = session
    }
    struct OpenAIErrorResponse: Decodable {
        struct APIError: Decodable {
            let message: String
            let type: String?
        }
        let error: APIError
    }
    // Sends user text → returns assistant text
    func sendMessage(_ message: String) async throws -> String {
        let url = URL(string: "https://api.openai.com/v1/responses")!

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "model": "gpt-4o-mini",
            "input": message
        ]

        // ✅ IMPORTANT: set body BEFORE sending
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        // ✅ Send only once
        let (data, response) = try await session.data(for: request)

        if let http = response as? HTTPURLResponse {
            print("✅ HTTP status:", http.statusCode)
        }

        // Debug raw response if parsing fails
        let raw = String(data: data, encoding: .utf8) ?? "❌ Could not decode raw text"
        print("📦 RAW RESPONSE:", raw)

        // Parse a simple text output (keep your current approach)
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        let output = json?["output"] as? [[String: Any]]

        if let first = output?.first,
           let content = first["content"] as? [[String: Any]] {
            for item in content {
                if let text = item["text"] as? String {
                    return text
                }
            }
        }

        return "No response text found."
    }
    
}
