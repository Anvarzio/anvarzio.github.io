//
//  Secrets.swift
//  Impulse
//
//  Created by Tony V on 2/28/26.
//

import Foundation

enum Secrets {
    static var openAIKey: String {
        guard
            let url = Bundle.main.url(forResource: "Secrets", withExtension: "plist"),
            let data = try? Data(contentsOf: url),
            let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
            let key = plist["OPENAI_API_KEY"] as? String,
            !key.isEmpty
        else {
            fatalError("Missing OPENAI_API_KEY in Secrets.plist")
        }
        return key
    }
}
