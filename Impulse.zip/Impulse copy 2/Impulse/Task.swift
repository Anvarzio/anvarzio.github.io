import Foundation

struct Task {
    var name: String
    var dueDate: Date
    var completionTimeHours: Double

    // Returns a priority value from 0.0 to 1.0
    // 1.0 = most urgent, 0.0 = least urgent
    func priorityScore() -> Double {
        let now = Date()
        let secondsRemaining = dueDate.timeIntervalSince(now)

        // Overdue tasks are maximum urgency
        if secondsRemaining <= 0 {
            return 1.0
        }

        // Prevent division issues
        if completionTimeHours <= 0 {
            return 0.0
        }

        let completionSeconds = completionTimeHours * 3600
        let ratio = secondsRemaining / completionSeconds

        // Brightest red if less than 3x completion time remains
        if ratio <= 3 {
            return 1.0
        }

        // Lightest red if more than 10x completion time remains
        if ratio >= 10 {
            return 0.0
        }

        // Scale linearly between 3 and 10
        return 1.0 - ((ratio - 3) / 7.0)
    }
}
