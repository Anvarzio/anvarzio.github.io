import Foundation

class TaskStore {
    static let shared = TaskStore()
    
    private init() { }
    
    var tasks: [Task] = []
}
