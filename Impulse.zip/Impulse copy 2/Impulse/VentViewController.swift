//
//  VentViewController.swift
//  Impulse
//
//  Created by Tony V on 2/28/26.
//

import Foundation
import UIKit

final class VentViewController: UIViewController {

    @IBOutlet weak var chatTextView: UITextView!
    @IBOutlet weak var messageTextField: UITextField!

    private lazy var openAI = OpenAIService(apiKey: Secrets.openAIKey)

    @IBAction func sendTapped(_ sender: UIButton) {
        let userText = messageTextField.text ?? ""
        guard !userText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        appendToChat("You: \(userText)\n")
        messageTextField.text = ""

        Swift.Task {
            do {
                let reply = try await openAI.sendMessage(userText)
                await MainActor.run {
                    self.appendToChat("AI: \(reply)\n\n")
                }
            } catch {
                await MainActor.run {
                    self.appendToChat("AI Error: \(error.localizedDescription)\n\n")
                }
            }
        }
    }

    private func appendToChat(_ text: String) {
        chatTextView.text = (chatTextView.text ?? "") + text
    }
    
    
}
