//
//  ViewController.swift
//  Impulse
//
//  Created by Tony V on 2/27/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view
        
        print("API KEY:", Secrets.openAIKey)
    }


}

